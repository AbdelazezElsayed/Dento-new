import DashboardStats from "../DashboardStats";

export default function DashboardStatsExample() {
  return (
    <div className="p-6 bg-background">
      <DashboardStats />
    </div>
  );
}
